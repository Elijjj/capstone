const mongoose = require("mongoose");

const checkoutSchema = mongoose.Schema({
  user: {
    type: mongoose.Schema.Types.ObjectId,
    ref: "User", // Reference to the User model
    required: true,
  },
  cartItems: [{
    type: mongoose.Schema.Types.ObjectId,
    ref: "CartItem", // Reference to the CartItem model
    required: true,
  }],
  orderDate: {
    type: Date,
    default: Date.now
  },
  totalPrice: {
    type: Number,
    required: true
  },
  status: {
    type: String,
    required: true,
    default: "Pending"
  },
  shippingAddress: {
    type: String,
    required: true,
  },
  paymentDetails: {
    type: Map,
    of: String
  },
});

const Checkout = mongoose.model("Checkout", checkoutSchema);

module.exports = Checkout;