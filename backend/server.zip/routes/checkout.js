const express = require('express');
const router = express.Router();
const checkoutController = require('../controllers/checkout');
const checkAuth = require('../middleware/check-auth');

router.get('/:id', checkAuth, checkoutController.getCheckout);

module.exports = router;
