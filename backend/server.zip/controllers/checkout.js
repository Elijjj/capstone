const Checkout = require('../models/checkout');

exports.getCheckout = (req, res, next) => {
    const cartId = req.params.cartId;

    cartService.getCheckout(cartId)
      .then(checkoutData => {
        res.status(200).json({
          message: 'Checkout data fetched successfully',
          checkoutData: checkoutData
        });
      })
      .catch(err => {
        res.status(500).json({ message: 'Error fetching checkout data', error: err });
      });
}